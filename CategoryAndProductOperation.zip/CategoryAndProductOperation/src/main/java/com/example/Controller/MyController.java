package com.example.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Category;
import com.example.Entity.Product;
import com.example.Service.MyService;

@RestController
public class MyController {
	@Autowired
	MyService service;
	@PostMapping("/save")
	public String saveinfo(@RequestBody Product p)
	{
		return service.save(p);
	}
	@GetMapping("/findbyid/{id}")
	public Product getall(@PathVariable("id")int id)
	{
		return service.getid(id);
	}
	@DeleteMapping("/deletebyid/{id}")
	public String delete(@PathVariable("id")int id)
	{
		return service.deleteid(id);
		
	}
	@PutMapping("/update/{id}")
	public String update(@PathVariable("id")int id,@RequestBody Product p)
	{
		return service.update(id, p);
	}
	@PostMapping("/newCategory")
	public String newdata(@RequestBody Category c)
	{
		return  service.save1(c);
	}
	@GetMapping("/getid/{id}")
	public Category getid(@PathVariable("id")int id)
	{
		return service.findid(id);
	}
	@PutMapping("/uddate/{id}")
	public String up(@PathVariable("id")int id,@RequestBody Category c)
	{
		return service.update1(id, c);
	}
	@DeleteMapping("/deletebyid1/{id}")
	public String delete1(@PathVariable("id")int id)
	{
		return service.deleteid(id);
		
	}
	@PostMapping("/onetomany")
	public String savecategory(@RequestBody Category c)
	{
		return service.onetomany(c);
	}
}
