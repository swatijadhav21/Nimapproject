package com.example.Service;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.Category;
import com.example.Entity.Product;

import com.example.Repository.CategoryRepository;
import com.example.Repository.ProductRepository;




@Service
public class MyService {
	
	@Autowired
	ProductRepository pro;
	
	public String save(Product p)
	{
		pro.save(p);
		return "product added successfully";
	}
	
	public Product getid(int id)
	{
		return pro.findById(id).orElse(null);
	}
	public String deleteid(int id)
	{
		pro.deleteById(id);
		return "1 record deleted successfully";
	}
	public String update(int id,Product p)
	{
		Product pr=pro.findById(id).orElse(null);
		if(p!=null)
		{
			if(p.getName()!=null)
			{
				pr.setName(p.getName());
			}
			if(p.getPrice()!=0.0)
			{
				pr.setPrice(p.getPrice());
			}
		}
		pro.save(pr);
		return "product updated successfully";
	}
	@Autowired
	CategoryRepository cr;
	public String save1(Category c)
	{
		cr.save(c);
		return "Category added successfully";
	}

	public Category findid(int id)
	{
		return cr.findById(id).orElse(null);
	}
	public String deleteid1(int id)
	{
		cr.deleteById(id);
		return "1 record deleted successfully";
	}
	public String update1(int id,Category c)
	{
		Category ct=cr.findById(id).orElse(null);
		if(c!=null)
		{
			if(c.getName()!=null)
			{
				ct.setName(c.getName());
			}
			
		}
		cr.save(ct);
		return "category updated successfully";
	}
	public String onetomany(Category ca)
	{
		for(Product p:ca.getPt())
		{
		 p.setCt(ca);
		}
	cr.save(ca);
		return "record added successfully";
	}
	
}
