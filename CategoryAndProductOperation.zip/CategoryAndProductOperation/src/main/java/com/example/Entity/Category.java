package com.example.Entity;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
@Entity
@Table(name="category_info")
public class Category {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int cid;
	String name;
	
	@OneToMany(mappedBy="ct",cascade=CascadeType.ALL,orphanRemoval=true)
	@JsonManagedReference
	List<Product> pt=new ArrayList<Product>();
	public Category() {
		super();
	}
	
	public Category(int id, String name) {
		super();
		this.cid = id;
		this.name = name;
	}

	public int getId() {
		return cid;
	}

	public void setId(int id) {
		this.cid = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Product> getPt() {
		return pt;
	}

	public void setPt(List<Product> pt) {
		this.pt = pt;
	}
	
}
